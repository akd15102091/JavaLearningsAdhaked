package DesignRateLimiter.DesignRateLimitedLLD;

public enum RateLimiterType {
    TOKEN_BUCKET, LEAKY_BUCKET
}
